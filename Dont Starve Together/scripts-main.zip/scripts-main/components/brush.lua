local Brush = Class(function(self, inst)
    self.inst = inst
end)

return Brush
