local CarnivalGameItem = Class(function(self, inst)
    self.inst = inst

end)

return CarnivalGameItem